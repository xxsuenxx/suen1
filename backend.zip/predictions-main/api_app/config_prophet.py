import pandas as pd
from prophet import Prophet
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from math import sqrt


def load_prediction_prophet(producto_selected, start_date, end_date):
    prophet_models = {}
    try:
        df = pd.read_csv("./assets/products.csv", dayfirst=True)
        print("Dataset cargado exitosamente.")
    except Exception as e:
        print(f"Error al cargar el dataset: {e}")
        df = None

    if df is not None:
        # Convertir la columna 'fecha' a datetime
        df['fecha'] = pd.to_datetime(df['fecha'], format="%d/%m/%Y")
        print("\nColumna 'fecha' convertida a tipo datetime.")

        # Verificar el tipo de dato actualizado
        print("\nInformación del DataFrame actualizada:")
        df.info()

        # Extraer año, mes y día como nuevas columnas
        df['año'] = df['fecha'].dt.year
        df['mes'] = df['fecha'].dt.month
        df['dia'] = df['fecha'].dt.day
        print("\nSe han extraído las columnas 'año', 'mes' y 'día'.")

        # Intento cargar el dataset en un DataFrame de Pandas
        df.columns = df.columns.str.strip().str.lower()
        df.rename(columns={'fecha': 'ds', 'ventas': 'y', 'precio': 'precio', 'stock': 'stock', 'producto': 'producto',
                           'tipo': 'tipo'}, inplace=True)
        df['ds'] = pd.to_datetime(df['ds'], format="%d/%m/%Y")
        print("Dataset cargado exitosamente.")

        # Filtrar los datos para el tipo 'Panes'
        panes_df = df[df['tipo'] == 'Panes'].copy()
        # Filtrar para obtener solo los productos de tipo 'Panes'
        print("DataFrame 'panes_df' creado.")

        # Crear lags de ventas
        panes_df['ventas_lag_1'] = panes_df['y'].shift(1)
        panes_df['ventas_lag_7'] = panes_df['y'].shift(7)
        panes_df['ventas_lag_30'] = panes_df['y'].shift(30)
        print("Se han creado las características de retardo (lags) en panes_df.")

        # Eliminar filas con NaN introducidos por los lags
        panes_df.dropna(inplace=True, subset=['ventas_lag_1', 'ventas_lag_7',
                                              'ventas_lag_30'])  # Especificamos las columnas para evitar eliminar otras posibles NaNs
        print("Filas con valores NaN (debido a los lags) eliminadas de panes_df.")

    if panes_df is not None:
        panes_df_grouped_prophet = panes_df.groupby('producto')
    df_prod = panes_df_grouped_prophet.get_group(producto_selected)

    if not df_prod.empty:
        print(f"\n🔮 Entrenando modelo Prophet para: {producto_selected}")
        df_prod_prophet = df_prod[['ds', 'y']].copy()
        df_prod_prophet.rename(columns={'ds': 'ds', 'y': 'y'}, inplace=True)
        df_prod_prophet = df_prod_prophet.sort_values(by='ds')
        # Dividir los datos para Prophet (manteniendo el orden temporal)
        train_size = int(len(df_prod_prophet) * 0.8)
        train_prophet = df_prod_prophet[:train_size]
        prophet_model = Prophet()
        prophet_model.fit(train_prophet)
        prophet_models[producto_selected] = prophet_model
        print(f"✅ Modelo Prophet entrenado para {producto_selected}.")
    else:
        return None
    try:
        fecha_inicio_dt = pd.to_datetime(start_date)
        fecha_fin_dt = pd.to_datetime(end_date)
    except ValueError:
        print("Error: Las fechas ingresadas no tienen el formato correcto. Use YYYY-MM-DD.")
        return None

    if not prophet_models:
        print("No se encontraron modelos Prophet entrenados en 'prophet_models'.")
        return None

    if producto_selected not in prophet_models:
        print(
            f"Error: No se encontró un modelo Prophet para el producto '{producto_selected}'. Los productos disponibles son: {', '.join(prophet_models.keys())}")
        return None

    # Crear un DataFrame con el rango de fechas
    fechas_rango = pd.date_range(start=fecha_inicio_dt, end=fecha_fin_dt, freq='D')
    future_dates_df = pd.DataFrame({'ds': fechas_rango})

    model = prophet_models[producto_selected]  # Obtener el modelo para el producto específico
    forecast = model.predict(future_dates_df)
    predicciones_producto = forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].copy()

    if not predicciones_producto.empty:
        # Redondear las predicciones a entero
        predicciones_producto['yhat'] = predicciones_producto['yhat'].round().astype(int)
        predicciones_producto['yhat_lower'] = predicciones_producto['yhat_lower'].round().astype(int)
        predicciones_producto['yhat_upper'] = predicciones_producto['yhat_upper'].round().astype(int)

        # Agregar una columna con el nombre del producto
        predicciones_producto['producto'] = producto_selected  # Esto ya tiene el nombre del producto
        print(f"\n📈 Predicciones para el producto '{producto_selected}' desde {start_date} hasta {end_date}:")
        print(predicciones_producto)
        return predicciones_producto
    else:
        print(
            f"\n⚠️ No se encontraron predicciones para el producto '{producto_selected}' desde {start_date} hasta {end_date}.")
        return None


def load_assessment_prophet(producto_selected):
    prophet_models = {}
    try:
        df = pd.read_csv("assets/products.csv")
        print("Dataset cargado exitosamente.")
    except Exception as e:
        print(f"Error al cargar el dataset: {e}")
        df = None

    if df is not None:
        # Convertir la columna 'fecha' a datetime
        df['fecha'] = pd.to_datetime(df['fecha'], format="%d/%m/%Y")
        print("\nColumna 'fecha' convertida a tipo datetime.")

        # Verificar el tipo de dato actualizado
        print("\nInformación del DataFrame actualizada:")
        df.info()

        # Extraer año, mes y día como nuevas columnas
        df['año'] = df['fecha'].dt.year
        df['mes'] = df['fecha'].dt.month
        df['dia'] = df['fecha'].dt.day
        print("\nSe han extraído las columnas 'año', 'mes' y 'día'.")

        # Intento cargar el dataset en un DataFrame de Pandas
        df.columns = df.columns.str.strip().str.lower()
        df.rename(columns={'fecha': 'ds', 'ventas': 'y', 'precio': 'precio', 'stock': 'stock', 'producto': 'producto',
                           'tipo': 'tipo'}, inplace=True)
        df['ds'] = pd.to_datetime(df['ds'], format="%d/%m/%Y")
        print("Dataset cargado exitosamente.")

        # Filtrar los datos para el tipo 'Panes'
        panes_df = df[df['tipo'] == 'Panes'].copy()
        # Filtrar para obtener solo los productos de tipo 'Panes'
        print("DataFrame 'panes_df' creado.")

        # Crear lags de ventas
        panes_df['ventas_lag_1'] = panes_df['y'].shift(1)
        panes_df['ventas_lag_7'] = panes_df['y'].shift(7)
        panes_df['ventas_lag_30'] = panes_df['y'].shift(30)
        print("Se han creado las características de retardo (lags) en panes_df.")

        # Eliminar filas con NaN introducidos por los lags
        panes_df.dropna(inplace=True, subset=['ventas_lag_1', 'ventas_lag_7',
                                              'ventas_lag_30'])  # Especificamos las columnas para evitar eliminar otras posibles NaNs
        print("Filas con valores NaN (debido a los lags) eliminadas de panes_df.")

    if panes_df is not None:
        panes_df_grouped_prophet = panes_df.groupby('producto')
    df_prod = panes_df_grouped_prophet.get_group(producto_selected)

    if not df_prod.empty:
        print(f"\n🔮 Entrenando modelo Prophet para: {producto_selected}")
        df_prod_prophet = df_prod[['ds', 'y']].copy()
        df_prod_prophet.rename(columns={'ds': 'ds', 'y': 'y'}, inplace=True)
        df_prod_prophet = df_prod_prophet.sort_values(by='ds')
        # Dividir los datos para Prophet (manteniendo el orden temporal)
        train_size = int(len(df_prod_prophet) * 0.8)
        train_prophet = df_prod_prophet[:train_size]
        prophet_model = Prophet()
        prophet_model.fit(train_prophet)
        prophet_models[producto_selected] = prophet_model
        print(f"✅ Modelo Prophet entrenado para {producto_selected}.")
    else:
        return None

    prophet_metrics = {}

    if panes_df is not None and prophet_models:
        panes_df_grouped_eval_prophet = panes_df.groupby('producto')
        df_prod = panes_df_grouped_eval_prophet.get_group(producto_selected)
        model = prophet_models[producto_selected]
        if model is not None:
            df_prod_prophet = df_prod[['ds', 'y']].copy()
            df_prod_prophet.rename(columns={'ds': 'ds', 'y': 'y'}, inplace=True)
            df_prod_prophet = df_prod_prophet.sort_values(by='ds')
            train_size = int(len(df_prod_prophet) * 0.8)
            test_prophet = df_prod_prophet[train_size:].copy()
            future = model.make_future_dataframe(periods=len(test_prophet), freq='D')
            forecast = model.predict(future)
            merged_forecast = forecast[['ds', 'yhat']].set_index('ds').join(test_prophet.set_index('ds'),
                                                                            how='inner')
            y_pred_prophet = merged_forecast['yhat'].round(0).astype(int)
            y_real_prophet = merged_forecast['y'].values
            mse_prophet = mean_squared_error(y_real_prophet, y_pred_prophet)
            rmse_prophet = sqrt(mse_prophet)
            mae_prophet = mean_absolute_error(y_real_prophet, y_pred_prophet)
            r2_prophet = r2_score(y_real_prophet, y_pred_prophet)
            prophet_metrics.setdefault(producto_selected, {})['mse'] = mse_prophet
            prophet_metrics.setdefault(producto_selected, {})['rmse'] = rmse_prophet
            prophet_metrics.setdefault(producto_selected, {})['mae'] = mae_prophet
            prophet_metrics.setdefault(producto_selected, {})['r2'] = r2_prophet
            print(
                f"  MSE: {mse_prophet:.2f}, RMSE: {rmse_prophet:.2f}, MAE: {mae_prophet:.2f}, R²: {r2_prophet:.2f}")
            return {
                'name_product': producto_selected,
                'mse': round(mse_prophet, 2),
                'rmse': round(rmse_prophet, 2),
                'mae': round(mae_prophet, 2),
                'r2': round(r2_prophet, 2),
            }
        else:
            return {}
    else:
        return {}
