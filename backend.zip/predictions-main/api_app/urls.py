from django.urls import path

from api_app.views import get_prediction_prophet
from api_app.views import get_assessment_prophet

urlpatterns = [
    path('prediction/', get_prediction_prophet),
    path('assessment/', get_assessment_prophet)
]
