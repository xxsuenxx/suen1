from drf_yasg.utils import swagger_auto_schema
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from api_app.config_prophet import load_prediction_prophet, load_assessment_prophet
from drf_yasg import openapi

paramsGetPredictionProphet = [
    openapi.Parameter(
        'producto', openapi.IN_QUERY,
        description="Nombre del producto (ej: Cachito)",
        type=openapi.TYPE_STRING, required=True
    ),
    openapi.Parameter(
        'fecha_inicio', openapi.IN_QUERY,
        description="Fecha de inicio (formato YYYY-MM-DD)",
        type=openapi.TYPE_STRING, required=True
    ),
    openapi.Parameter(
        'fecha_fin', openapi.IN_QUERY,
        description="Fecha de fin (formato YYYY-MM-DD)",
        type=openapi.TYPE_STRING, required=True
    ),
]

paramsGetErrorProphet = [
    openapi.Parameter(
        'producto', openapi.IN_QUERY,
        description="Nombre del producto (ej: Cachito)",
        type=openapi.TYPE_STRING, required=True
    ),
]


@swagger_auto_schema(
    method='get',
    manual_parameters=paramsGetPredictionProphet,
    operation_description="Genera predicción de ventas con Prophet entre dos fechas para un producto.",
    responses={200: 'Predicción generada correctamente'}
)
@api_view(['GET'])
def get_prediction_prophet(request):
    producto = request.GET.get('producto')
    fecha_inicio = request.GET.get('fecha_inicio')
    fecha_fin = request.GET.get('fecha_fin')
    if not all([producto, fecha_inicio, fecha_fin]):
        return Response({'error': 'Faltan parámetros'}, status=status.HTTP_400_BAD_REQUEST)
    try:
        resultado = load_prediction_prophet(producto, fecha_inicio, fecha_fin)
        if resultado is None:
            return Response({'error': 'No se pudo generar la predicción'}, status=status.HTTP_404_NOT_FOUND)

        return Response(resultado.to_dict(orient='records'))  # Devuelve JSON
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@swagger_auto_schema(
    method='get',
    manual_parameters=paramsGetErrorProphet,
    operation_description="Genera Evaluación MSE, RMSE, MAE, R²",
    responses={200: 'Evaluación generada correctamente'}
)
@api_view(['GET'])
def get_assessment_prophet(request):
    producto = request.GET.get('producto')
    if not all([producto]):
        return Response({'error': 'Faltan parámetros'}, status=status.HTTP_400_BAD_REQUEST)
    try:
        resultado = load_assessment_prophet(producto)
        if resultado is None:
            return Response({'error': 'No se pudo generar la predicción'}, status=status.HTTP_404_NOT_FOUND)

        return Response(resultado)  # Devuelve JSON
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
