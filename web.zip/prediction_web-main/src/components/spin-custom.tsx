import { Flex, Spin } from "antd";
const contentStyle: React.CSSProperties = {
    padding: 50,
    background: 'rgba(0, 0, 0, 0.05)',
    borderRadius: 4,
};

const content = <div style={contentStyle} />;
const SpinCustom: React.FC = () => (
    <Flex gap="middle" className="flex justify-center h-screen" vertical>
        <Flex gap="middle" className="w-full" vertical>
            <Spin tip="Loading" size="large" className="custom-spinner custom-text-spinner">
                {content}
            </Spin>
        </Flex>
    </Flex>
);

export default SpinCustom;