import { Alert } from 'antd';
type Props = {
    alertMessage: string;
    type?: 'success' | 'info' | 'warning' | 'error';
};

const AlertCustom = ({ alertMessage, type }: Props) => (
    <Alert message={alertMessage} type={type} showIcon />
);

export default AlertCustom;