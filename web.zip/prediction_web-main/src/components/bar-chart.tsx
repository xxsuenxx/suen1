import React from "react";
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    BarElement,
    Title,
    Tooltip,
    Legend,
    Filler,
} from "chart.js";
import {Bar} from "react-chartjs-2";
import {PredictionResult} from "@/models/prediction_result.model";

ChartJS.register(CategoryScale, LinearScale, PointElement, BarElement, Title, Tooltip, Legend, Filler);

interface PropsData {
    dataPrediction: PredictionResult[];
}

class BarChart extends React.Component<PropsData> {
    render() {
        const {dataPrediction} = this.props;

        const labelDays = dataPrediction?.map(item => {
            const date = new Date(item.ds);
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0'); // Mes inicia en 0
            return `${day}/${month}`;
        });

        const listDataSet = [
            {
                label: "Cant. Promedio",
                data: dataPrediction?.map(item => {
                    return item.yhat;
                }),
                backgroundColor: "#5ECAA2",
                borderColor: "#5ECAA2",
                borderWidth: 0,
            }, {
                label: "Cant. Minimo",
                data: dataPrediction?.map(item => {
                    return item.yhat_lower;
                }),
                backgroundColor: "#AFA081",
                borderColor: "#AFA081",
                borderWidth: 0,
            }, {
                label: "Cant. Maximo",
                data: dataPrediction?.map(item => {
                    return item.yhat_upper;
                }),
                backgroundColor: "#6E5549",
                borderColor: "#6E5549",
                borderWidth: 0,
            }
        ]


        let maxYhat = -Infinity;
        let maxYhatLower = -Infinity;
        let maxYhatUpper = -Infinity;
        dataPrediction.forEach(item => {
            if (item.yhat > maxYhat) maxYhat = item.yhat;
            if (item.yhat_lower > maxYhatLower) maxYhatLower = item.yhat_lower;
            if (item.yhat_upper > maxYhatUpper) maxYhatUpper = item.yhat_upper;
        });

        const maxTotal = Math.max(maxYhat, maxYhatLower, maxYhatUpper);

        const data = {
            labels: labelDays,
            datasets: listDataSet,
        };
        const options = {
            maintainAspectRatio: false,
            scales: {
                y: {
                    title: {
                        display: true,
                        text: "Cantidad panes vendido",
                    },
                    display: true,
                    beginAtZero: true,
                    max: maxTotal ?? 0,
                },
                x: {
                    title: {
                        display: true,
                        text: "Rango de dias",
                    },
                    display: true,
                },
            },
        };
        return (
            <div className='h-[500px]' style={{width: "100%", backgroundColor: "white", borderRadius: "10px"}}>
                <Bar data={data} options={options}/>
            </div>
        );
    }
}

export default BarChart;