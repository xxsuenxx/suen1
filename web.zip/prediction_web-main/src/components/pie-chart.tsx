import React from "react";
import {
    Chart as ChartJS,
    Tooltip,
    Legend,
    ArcElement
} from "chart.js";
import {Pie} from "react-chartjs-2";
import {AssessmentResult} from "@/models/assessment_result.model";

ChartJS.register(ArcElement, Tooltip, Legend);

interface PropsData {
    dataAssessment: AssessmentResult;
}

class PieChart extends React.Component<PropsData> {
    render() {
        const {dataAssessment} = this.props;
        const data = {
            labels: ["MSE","RMSE", "MAE","R²"],
            datasets: [
                {
                    label: 'Distribución de colores',
                    data: [dataAssessment.mse, dataAssessment.rmse, dataAssessment.mae, dataAssessment.r2],
                    backgroundColor: ['#538EA7', '#70C675', '#FF5449','#919093'],
                    borderColor: ['#000000'],
                    borderWidth: 0,
                },
            ],
        };
        return (
            <div
                style={{
                    width: "100%",
                    backgroundColor: "white",
                    borderRadius: "10px",
                    padding: "10px",
                    alignContent: "center"
                }}>
                <Pie data={data}/>
                <div
                    style={{
                        color: "black",
                        lineHeight: "39px",
                        textAlign: "start"
                    }}>
                    MSE : {dataAssessment.mse}
                    <br/>
                    RMSE : {dataAssessment.rmse}
                    <br/>
                    MAE : {dataAssessment.mae}
                    <br/>
                    R² : {dataAssessment.r2}
                </div>
            </div>
        );
    }
}

export default PieChart;