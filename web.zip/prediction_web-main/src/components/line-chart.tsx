"use client";
import React from "react";
import dynamic from "next/dynamic";
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
} from "chart.js";

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend
);

const LineChart = dynamic(
    () => import("react-chartjs-2").then((mod) => mod.Line),
    {ssr: false}
);

export class LineChartCustom extends React.Component<{ statusLoadedData: any }> {
    render() {
        const {statusLoadedData} = this.props;
        const labelMonths = ['Enero, 2025', 'Febrero, 2025', 'Marzo, 2025', 'Abril, 2025', 'Mayo, 2025'];
        const listPan = [
            {
                label: "Pan Chabatta",
                data: [23200, 21000, 18843, 15033, 8000],
                backgroundColor: "#C62828",
                borderColor: "#C62828",
                borderWidth: 1,
            }, {
                label: "Pan Francés",
                data: [17200, 26000, 19343, 6732, 3999],
                backgroundColor: "#AD1457",
                borderColor: "#AD1457",
                borderWidth: 1,
            }, {
                label: "Pan Yema Largo",
                data: [32333, 24533, 18843, 32999, 4500],
                backgroundColor: "#6A1B9A",
                borderColor: "#6A1B9A",
                borderWidth: 1,
            }, {
                label: "Pan Yema Redondo",
                data: [16883, 28883, 19873, 34222, 5647],
                backgroundColor: "#283593",
                borderColor: "#283593",
                borderWidth: 1,
            }, {
                label: "Pan Chapla",
                data: [22400, 18330, 20873, 22736, 6589],
                backgroundColor: "#1565C0",
                borderColor: "#1565C0",
                borderWidth: 1,
            }, {
                label: "Pan Coliza",
                data: [18933, 23111, 19224, 21487, 7239],
                backgroundColor: "#2E7D32",
                borderColor: "#2E7D32",
                borderWidth: 1,
            }, {
                label: "Pan Integral",
                data: [21988, 21111, 14999, 23555, 9831],
                backgroundColor: "#FF8F00",
                borderColor: "#FF8F00",
                borderWidth: 1,
            }, {
                label: "Pan Caracol",
                data: [21211, 20221, 18888, 27623, 4999],
                backgroundColor: "#4E342E",
                borderColor: "#4E342E",
                borderWidth: 1,
            }, {
                label: "Pan Hamburguesa",
                data: [27939, 21550, 18143, 28033, 10290],
                backgroundColor: "#424242",
                borderColor: "#424242",
                borderWidth: 1,
            }, {
                label: "Cachito",
                data: [23200, 21000, 18843, 25033, 8000],
                backgroundColor: "#37474F",
                borderColor: "#37474F",
                borderWidth: 1,
            }
        ]
        const options = {
            maintainAspectRatio: false,
            responsive: true,
            scales: {
                x: {
                    beginAtZero: true,
                },
                y: {
                    beginAtZero: false,
                    min: 60,
                },
            },
        }

        return (
            <div className='h-[500px]'
                 style={{width: "100%", backgroundColor: "white", borderRadius: "10px", padding: "20px"}}>
                <LineChart
                    data={{
                        labels: statusLoadedData ? labelMonths : [],
                        datasets: statusLoadedData ? listPan : [],
                    }}
                    options={options}
                />
            </div>
        );
    }
}