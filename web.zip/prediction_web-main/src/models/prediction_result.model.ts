export interface PredictionResult {
    ds: string;
    yhat: number;
    yhat_lower: number;
    yhat_upper: number;
    producto: string;
}