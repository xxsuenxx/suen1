export interface AssessmentResult {
    name_product: string;
    mse: number;
    rmse: number;
    mae: number;
    r2: string;
}