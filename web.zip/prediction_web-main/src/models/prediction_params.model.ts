export interface PredictionParams {
    producto: string;
    fecha_inicio: string;  // format YYYY-MM-DD
    fecha_fin: string; // format YYYY-MM-DD
}