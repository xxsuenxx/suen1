import {PredictionParams} from "@/models/prediction_params.model";
import {PredictionResult} from "@/models/prediction_result.model";
import {AssessmentResult} from "@/models/assessment_result.model";

export async function getPrediction(params: PredictionParams): Promise<PredictionResult[]> {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/prediction/?producto=${params.producto}&fecha_inicio=${params.fecha_inicio}&fecha_fin=${params.fecha_fin}`);
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Error al obtener la predicción: ${errorText}`);
    }
    const data: PredictionResult[] = await response.json();
    return data;
}


export async function getAssessment(params: PredictionParams): Promise<AssessmentResult> {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/assessment/?producto=${params.producto}`);
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Error al obtener la evaluación: ${errorText}`);
    }
    const data: AssessmentResult = await response.json();
    return data;
}