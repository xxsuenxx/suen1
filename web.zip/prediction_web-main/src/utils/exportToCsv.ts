import {PredictionResult} from "@/models/prediction_result.model";
import {toast} from "sonner";
import {formatDate} from "@/utils/format_date";

export const onGetCsvProduct = async (predictionResult: PredictionResult[]) => {
    try {
        if (predictionResult && Array.isArray(predictionResult)) {
            const csvContent = "data:text/csv;charset=utf-8," +
                "Producto, Fecha, Cantidad Minimo, Cantidad Maximo, Promedio\n" +
                predictionResult.map((predictionData: PredictionResult) =>
                    `"${predictionData.producto}", ${formatDate(predictionData.ds)},"${predictionData.yhat_lower}","${predictionData.yhat_upper}","${predictionData.yhat}"`
                ).join("\n");

            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "prediction.csv");
            document.body.appendChild(link);
            link.click();
            toast.success('El archivo CSV se generó correctamente.');
        } else {
            toast.error("Ocurrió un error al crear el archivo CSV.");
        }
    } catch (error: any) {
        toast.error(`Error: ${error}`);
    }
};