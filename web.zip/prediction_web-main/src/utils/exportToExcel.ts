import * as XLSX from "xlsx";
import {PredictionResult} from "@/models/prediction_result.model";
import {toast} from "sonner";
import {formatDate} from "@/utils/format_date";

export const onGetExcelProduct = async (predictionResult: PredictionResult[]) => {
    try {
        if (predictionResult && Array.isArray(predictionResult)) {
            const dataToExport = predictionResult.map((predictionData: PredictionResult) => ({
                    'Producto': predictionData.producto,
                    'Fecha': formatDate(predictionData.ds),
                    'Cantidad Minimo': predictionData.yhat_lower,
                    'Cantidad Maximo': predictionData.yhat_upper,
                    'Promedio': predictionData.yhat
                })
                ,);
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils?.json_to_sheet(dataToExport);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Prediction");
            XLSX.writeFile(workbook, `prediction.xlsx`);
            toast.success('El archivo Excel se generó correctamente.');
        } else {
            toast.error("Ocurrió un error al crear el archivo Excel.");
        }
    } catch (error: any) {
        toast.error(`Error: ${error}`);
    }
};