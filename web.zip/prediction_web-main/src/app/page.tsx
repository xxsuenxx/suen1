'use client';

import SpinCustom from "@/components/spin-custom";
import {auth} from "@/firebase/config";
import {useRouter} from 'next/navigation';
import React from 'react';
import {useEffect} from 'react';

export default function Home() {
    const router = useRouter();
    const onReload = async () => {
        try {
            auth.onAuthStateChanged(async (user) => {
                if (user) {
                    const token = await user.getIdToken();
                    localStorage.setItem("token", token);
                    router.push('/dashboard');
                } else {
                    console.log('not_info');
                    router.push('/login');
                }
            });
        } catch (error: any) {
            console.log('error_onReload', error);
        }
    };
    useEffect(() => {
        onReload();
    });
    return (
        <SpinCustom/>
    );
}
