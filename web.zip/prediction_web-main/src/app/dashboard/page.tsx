'use client';
import React from 'react';
import {useState, useEffect} from 'react';
import {signOut} from 'firebase/auth';
import {auth} from '@/firebase/config';
import {useRouter} from 'next/navigation';
import {DownOutlined} from '@ant-design/icons';
import {
    Button,
    Flex,
    Dropdown,
    MenuProps,
    DatePicker
} from "antd";
import {Content, Footer, Header} from 'antd/es/layout/layout';
import BarChart from '@/components/bar-chart';
import {toast, Toaster} from 'sonner';
import LoadingSpinner from "@/components/loading_spinner";
import {getAssessment, getPrediction} from "@/lib/api";
import {PredictionResult} from "@/models/prediction_result.model";
import {onGetExcelProduct} from "@/utils/exportToExcel"
import {onGetCsvProduct} from "@/utils/exportToCsv"
import dayjs from "dayjs";
import {AssessmentResult} from "@/models/assessment_result.model";
import PieChart from "@/components/pie-chart";

const {RangePicker} = DatePicker;

const DashboardPage = () => {
    const headerStyle: React.CSSProperties = {
        textAlign: 'center',
        color: '#fff',
        height: 64,
        paddingInline: 48,
        lineHeight: '64px',
        backgroundColor: '#181818',
    };

    const contentStyle: React.CSSProperties = {
        textAlign: 'center',
        minHeight: 120,
        lineHeight: '120px',
        color: '#fff',
    };

    const footerStyle: React.CSSProperties = {
        textAlign: 'center',
        color: '#fff',
        backgroundColor: '#181818',
    };
    const items: MenuProps['items'] = [
        {
            label: 'Pan Cachito',
            key: 'Cachito',
        },
        {
            label: 'Pan Caracol',
            key: 'Pan Caracol',
        },
        {
            label: 'Pan Chabatta',
            key: 'Pan Chabatta',
        },
        {
            label: 'Pan Chapla',
            key: 'Pan Chapla',
        },
        {
            label: 'Pan Coliza',
            key: 'Pan Coliza',
        },
        {
            label: 'Pan Francés',
            key: 'Pan Francés'
        },
        {
            label: 'Pan Hamburguesa',
            key: 'Pan Hamburguesa',
        },
        {
            label: 'Pan Integral',
            key: 'Pan Integral',
        },
        {
            label: 'Pan Manjar',
            key: 'Pan Manjar',
        },
        {
            label: 'Pan Yema Largo',
            key: 'Pan Yema Largo',
        },
        {
            label: 'Pan Yema Redondo',
            key: 'Pan Yema Redondo',
        }
    ];


    const [dataPrediction, setDataPrediction] = useState<PredictionResult[] | null>(null);
    const router = useRouter();
    const [emailSaved, setEmailSaved] = useState('');
    const [statusLoadingPrediction, setStatusLoadingPrediction] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState('');
    const [range, setRange] = useState<[string, string] | []>([]);

    const [dataAssessment, setDataAssessment] = useState<AssessmentResult | null>(null);

    useEffect(() => {
        const userName = localStorage.getItem("email");
        if (userName) {
            setEmailSaved(userName);
        }
    }, [])

    const handleMenuClick: MenuProps['onClick'] = (e) => {
        setSelectedProduct(e.key);
    };

    const menuProps = {
        items,
        onClick: handleMenuClick,
    };

    const closeSession = async () => {
        await signOut(auth);
        localStorage.clear();
        router.push('/');
    };

    const eventLoadedData = async () => {
        if (selectedProduct.length == 0) {
            toast.error('Selecione un producto');
            return;
        }
        if (range.length < 2) {
            toast.error('Selecione un rango de fecha');
            return;
        }
        setStatusLoadingPrediction(true);
        await getPrediction({
            producto: selectedProduct,
            fecha_inicio: range[0] ?? '',
            fecha_fin: range[1] ?? ''
        })
            .then(data => {
                setDataPrediction(data);
                setStatusLoadingPrediction(false);
                toast.success('¡Datos cargados!');
            })
            .catch((err) => {
                setStatusLoadingPrediction(false);
                toast.error(`Error: ${err}`);
            });

        await getAssessment({
            producto: selectedProduct,
            fecha_inicio: '', fecha_fin: ''
        }).then(data => {
            setDataAssessment(data);
            setStatusLoadingPrediction(false);
        })
            .catch((err) => {
                setStatusLoadingPrediction(false);
                toast.error(`Error: ${err}`);
            });
    };


    return (
        <main>
            <Flex
                vertical
                align="center"
                justify="center">
                <Header className="w-full bg-neutral-900 text-white shadow min-h-[90px]" style={{...headerStyle}}>
                    <div
                        className="w-full max-w-7xl mx-auto px-4 min-h-[80px] flex flex-col sm:flex-row justify-between items-center gap-2">
                        <div className="text-sm sm:text-base text-center sm:text-left w-full sm:w-auto truncate">
                            Bienvenido: {emailSaved}
                        </div>
                        <div className="w-full sm:w-auto flex justify-center sm:justify-end">
                            <Button
                                type="primary"
                                className="w-full sm:w-auto"
                                onClick={closeSession}>
                                Cerrar Sesión
                            </Button>
                        </div>
                    </div>
                </Header>
                <Content style={contentStyle} className='flex-1 w-full'>
                    <div className='flex min-h-[calc(100vh-158px)] w-full items-star justify-center'>
                        <div className="max-w-full w-full">
                            <div
                                className="flex flex-col sm:flex-row flex-wrap justify-center items-center gap-2 w-full px-4 mt-4">
                                <Dropdown menu={menuProps}>
                                    <Button className="w-full sm:w-auto custom-height">
                                        {selectedProduct !== '' ? selectedProduct : 'Tipo de productos'}
                                        <DownOutlined/>
                                    </Button>
                                </Dropdown>

                                <RangePicker
                                    format="YYYY-MM-DD"
                                    minDate={dayjs('2025-04-01', 'YYYY-MM-DD')}
                                    onChange={(value, dateString) => setRange(dateString)}
                                    className="w-full sm:w-auto max-w-full"
                                    getPopupContainer={(triggerNode: HTMLElement) => triggerNode.parentElement || document.body}
                                />

                                <Button type="primary" className="w-full sm:w-auto custom-height"
                                        onClick={eventLoadedData}>
                                    Ejecutar Predicción
                                </Button>
                            </div>

                            {(dataPrediction?.length ?? 0) > 0 && (
                                <div
                                    className="flex flex-col sm:flex-row flex-wrap justify-center items-center gap-2 w-full px-4 mt-4">
                                    <Button
                                        type="primary" className="w-full sm:w-auto custom-height"
                                        onClick={() => onGetExcelProduct(dataPrediction!)}>
                                        Descargar Excel
                                    </Button>
                                    <Button type="primary" className="w-full sm:w-auto custom-height"
                                            onClick={() => onGetCsvProduct(dataPrediction!)}>
                                        Descargar CSV
                                    </Button>
                                </div>
                            )}
                            {statusLoadingPrediction ? (
                                LoadingSpinner()) : (
                                <div className="flex flex-col lg:flex-row justify-center items-start flex-wrap gap-2">
                                    <div className="w-full lg:w-[70%] h-1/2 relative p-4">
                                        {dataPrediction && <BarChart dataPrediction={dataPrediction}/>}
                                    </div>

                                    <div className="w-full lg:w-[25%] h-1/2 relative p-4">
                                        {dataAssessment && (
                                            <PieChart dataAssessment={dataAssessment}/>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </Content>
                <Footer className='w-full' style={footerStyle}>Footer</Footer>
            </Flex>
            <Toaster richColors position="bottom-center"/>
        </main>
    );
}

export default DashboardPage;