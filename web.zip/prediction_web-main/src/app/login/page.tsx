'use client';
import React from 'react';
import {useState, useEffect} from 'react';
import {signInWithEmailAndPassword} from 'firebase/auth';
import {auth} from '@/firebase/config';
import {useRouter} from 'next/navigation';
import {Button, Checkbox, Flex, Form, Input, FormProps} from "antd";
import AlertCustom from '../../components/alert-custom';
import {Content, Footer, Header} from 'antd/es/layout/layout';
import Image from 'next/image';

const LoginPage = () => {
    const router = useRouter();
    // const [email, setEmail] = useState('');
    // const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const [form] = Form.useForm();
    // const { data: session } = useSession();
    const [isFormValid, setIsFormValid] = useState(false);
    const [loading, setloading] = useState(false);
    const onFinish = async (values: any) => {
        try {
            setloading(true);
            const userLogged = await signInWithEmailAndPassword(auth, values.email, values.password);
            console.log('userLogged', userLogged);
            if (userLogged.user !== null) {
                localStorage.setItem("token", userLogged.user.refreshToken ?? "");
                localStorage.setItem("email", userLogged.user.email ?? "");
                localStorage.setItem("name", userLogged.user.displayName ?? "");
                setloading(false);
                router.push('/dashboard');
            }
            setloading(false);
        } catch (error: any) {
            console.log(error);
            setloading(false);
            setError(error.message);
        }
    };
    const onFinishFailed: FormProps['onFinishFailed'] = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };
    const handleFormChange = () => {
        const hasErrors = form
            .getFieldsError()
            .some(({errors}) => errors.length > 0);
        const hasTouchedFields = form.isFieldsTouched(["email", "password"], true);
        setIsFormValid(!hasErrors && hasTouchedFields);
    };

    useEffect(() => {
        // console.log(session);
        // if (session) {
        //     // localStorage.setItem("token", session.user.access_token);
        //     // localStorage.setItem("email", session.user.email);
        //     // localStorage.setItem("name", session.user.name);
        //     // useGeneralDataStore.setState({
        //     //     user: {
        //     //         email: session.user.email ?? "",
        //     //         name: session.user.name ?? "",
        //     //         id: session.user.id ?? "",
        //     //     },
        //     // });
        // } router.push("/");
    })


    // const handleLogin = async () => {
    //     try {
    //         const userLogged = await signInWithEmailAndPassword(auth, email, password);
    //         console.log('userLogged', userLogged);
    //         if (userLogged.user.email) {
    //             router.push('/dashboard');
    //         } else {
    //             setError('Usuario no encontrado');
    //         }
    //     } catch (error: any) {
    //         console.log(error);
    //         // if (error.code === 'auth/user-not-found') {
    //         //     handleRegister();
    //         // } else {
    //         setError(error.message);
    //         // }
    //     }
    // };

    // const handleRegister = async () => {
    //     try {
    //         await createUserWithEmailAndPassword(auth, email, password);
    //         router.push('/dashboard');
    //     } catch (error: any) {
    //         console.log(error);
    //         if (error.code === 'auth/email-already-in-use') {
    //             setError(error.message);
    //         }
    //     }
    // };

    const headerStyle: React.CSSProperties = {
        textAlign: 'center',
        color: '#fff',
        height: 64,
        paddingInline: 48,
        lineHeight: '64px',
        backgroundColor: '#181818',
    };

    const contentStyle: React.CSSProperties = {
        textAlign: 'center',
        minHeight: 120,
        lineHeight: '120px',
        color: '#fff',
    };

    const footerStyle: React.CSSProperties = {
        textAlign: 'center',
        color: '#fff',
        backgroundColor: '#181818',
    };


    return (
        <main>
            <Flex
                vertical
                align="center"
                justify="center">
                <Header className='w-full' style={headerStyle}>Iniciar Sesión</Header>
                <Content style={contentStyle} className='w-full'>
                    <div className='flex min-h-[calc(100vh-128px)] w-full px-4 sm:px-0 items-center justify-center'>
                        <Form
                            form={form}
                            initialValues={{ remember: true }}
                            onFieldsChange={handleFormChange}
                            layout="vertical"
                            scrollToFirstError
                            className="w-full sm:w-1/2 md:w-1/3 lg:w-1/4 px-4 sm:px-0"
                            onFinish={onFinish}
                            onFinishFailed={onFinishFailed}
                        >
                            <div className="flex justify-center mb-6">
                                <Image
                                    src="/logo_panaderia.png"
                                    alt="Logo"
                                    width={200}
                                    height={200}
                                    priority
                                />
                            </div>
                            <Form.Item
                                label="Correo electrónico"
                                name="email"
                                required
                                rules={[
                                    {
                                        type: "email",
                                        message: "El correo electrónico no es válido",
                                    },
                                    {
                                        required: true,
                                        message: "Ingrese su correo electrónico",
                                    },
                                ]} className="text-left">
                                <Input size="large" placeholder="Escribe correo electrónico"/>
                            </Form.Item>
                            <Form.Item
                                label="Contraseña"
                                name="password"
                                required
                                rules={[
                                    {
                                        required: true,
                                        message: "Ingresa tu contraseña",
                                    },
                                    // length of password 8-20
                                    {
                                        min: 6,
                                        message: "La contraseña debe tener al menos 6 caracteres!",
                                    },
                                    {
                                        max: 20,
                                        message: "Password must be at most 20 characters!",
                                    },
                                ]}
                                hasFeedback className="text-left">
                                <Input.Password size="large" placeholder="Escribe tu contraseña"/>
                            </Form.Item>
                            <div className="flex justify-between items-start">
                                <Form.Item
                                    name="remember"
                                    className="self-start"
                                    valuePropName="checked">
                                    <Checkbox>Recordarme</Checkbox>
                                </Form.Item>
                            </div>

                            <Form.Item>
                                <Button
                                    size="large"
                                    className="bg-primary-purple-3 rounded-full w-full mt-2"
                                    style={{
                                        background: isFormValid ? "#072E4A" : "#99A1AF",
                                        color: "white",
                                        fontWeight: "500",
                                    }}
                                    htmlType="submit"
                                    loading={loading}>
                                    Iniciar sesión
                                </Button>
                            </Form.Item>
                            {error && <AlertCustom alertMessage={error} type='error'/>}
                        </Form>
                    </div>
                </Content>
                <Footer className='w-full' style={footerStyle}>Footer</Footer>
            </Flex>
        </main>
    );
}

export default LoginPage;