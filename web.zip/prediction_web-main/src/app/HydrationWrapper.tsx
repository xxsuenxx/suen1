"use client";
import {ReactNode, useEffect, useState} from "react";

type HydrationWrapperProps = {
    children: ReactNode;
};

export default function HydrationWrapper({ children }: HydrationWrapperProps) {
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    if (!mounted) return null;

    return <>{children}</>;
}